﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateMenuPageTablePKv19 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_MenuPage_AddedByUserId",
                schema: "lst",
                table: "MenuPage",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_MenuPage_LastModifiedByUserId",
                schema: "lst",
                table: "MenuPage",
                column: "LastModifiedByUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_MenuPage_AddedByUserId_User_Id",
                schema: "lst",
                table: "MenuPage",
                column: "AddedByUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_MenuPage_LastModifiedByUserId_User_Id",
                schema: "lst",
                table: "MenuPage",
                column: "LastModifiedByUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MenuPage_AddedByUserId_User_Id",
                schema: "lst",
                table: "MenuPage");

            migrationBuilder.DropForeignKey(
                name: "FK_MenuPage_LastModifiedByUserId_User_Id",
                schema: "lst",
                table: "MenuPage");

            migrationBuilder.DropIndex(
                name: "IX_MenuPage_AddedByUserId",
                schema: "lst",
                table: "MenuPage");

            migrationBuilder.DropIndex(
                name: "IX_MenuPage_LastModifiedByUserId",
                schema: "lst",
                table: "MenuPage");
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class AddActionAndControllerLstTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApiControllerDescription",
                schema: "idn",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "ApiControllerDescription tanım tablosunun primary keyi")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddedByUserId = table.Column<int>(type: "int", nullable: false, defaultValueSql: "((1))"),
                    AddedTime = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "getdate()"),
                    LastModifiedByUserId = table.Column<int>(type: "int", nullable: true),
                    LastModifiedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))"),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "((0))")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApiControllerDescription", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApiControllerDescription_AddedByUserId_User_Id",
                        column: x => x.AddedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ApiControllerDescription_LastModifiedByUserId_User_Id",
                        column: x => x.LastModifiedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ApiActionDescription",
                schema: "idn",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "ApiActionDescription tanım tablosunun primary keyi")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ApiControllerDescriptionId = table.Column<int>(type: "int", nullable: false),
                    AddedByUserId = table.Column<int>(type: "int", nullable: false, defaultValueSql: "((1))"),
                    AddedTime = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "getdate()"),
                    LastModifiedByUserId = table.Column<int>(type: "int", nullable: true),
                    LastModifiedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))"),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "((0))")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApiActionDescription", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApiActionDescription_AddedByUserId_User_Id",
                        column: x => x.AddedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ApiActionDescription_ApiControllerDescription_ApiControllerDescriptionId",
                        column: x => x.ApiControllerDescriptionId,
                        principalSchema: "idn",
                        principalTable: "ApiControllerDescription",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApiActionDescription_LastModifiedByUserId_User_Id",
                        column: x => x.LastModifiedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ApiActionDescription_AddedByUserId",
                schema: "idn",
                table: "ApiActionDescription",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ApiActionDescription_ApiControllerDescriptionId",
                schema: "idn",
                table: "ApiActionDescription",
                column: "ApiControllerDescriptionId");

            migrationBuilder.CreateIndex(
                name: "IX_ApiActionDescription_LastModifiedByUserId",
                schema: "idn",
                table: "ApiActionDescription",
                column: "LastModifiedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ApiControllerDescription_AddedByUserId",
                schema: "idn",
                table: "ApiControllerDescription",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ApiControllerDescription_LastModifiedByUserId",
                schema: "idn",
                table: "ApiControllerDescription",
                column: "LastModifiedByUserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApiActionDescription",
                schema: "idn");

            migrationBuilder.DropTable(
                name: "ApiControllerDescription",
                schema: "idn");
        }
    }
}

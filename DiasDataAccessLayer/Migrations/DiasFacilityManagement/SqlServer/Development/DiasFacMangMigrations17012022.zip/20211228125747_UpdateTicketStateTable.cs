﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateTicketStateTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "StateDescription",
                schema: "lst",
                table: "TicketState",
                newName: "Name");

            migrationBuilder.AddColumn<string>(
                name: "NormalizedName",
                schema: "lst",
                table: "TicketState",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NormalizedName",
                schema: "lst",
                table: "TicketState");

            migrationBuilder.RenameColumn(
                name: "Name",
                schema: "lst",
                table: "TicketState",
                newName: "StateDescription");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class AddBasicTicketStateFkToBasicTicketv2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "StateId",
                schema: "usr",
                table: "BasicTicket",
                type: "int",
                nullable: false,
                defaultValueSql: "((9))");

            migrationBuilder.CreateIndex(
                name: "IX_BasicTicket_StateId",
                schema: "usr",
                table: "BasicTicket",
                column: "StateId");

            migrationBuilder.AddForeignKey(
                name: "FK_BasicTicket_BasicTicketState_StateId_Id",
                schema: "usr",
                table: "BasicTicket",
                column: "StateId",
                principalSchema: "lst",
                principalTable: "BasicTicketState",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BasicTicket_BasicTicketState_StateId_Id",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropIndex(
                name: "IX_BasicTicket_StateId",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropColumn(
                name: "StateId",
                schema: "usr",
                table: "BasicTicket");
        }
    }
}

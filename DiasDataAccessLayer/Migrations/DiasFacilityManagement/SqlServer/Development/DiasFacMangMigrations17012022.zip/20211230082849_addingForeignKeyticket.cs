﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class addingForeignKeyticket : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {         
            migrationBuilder.CreateIndex(
                name: "IX_Ticket_PeriodicTicketId",
                schema: "usr",
                table: "Ticket",
                column: "PeriodicTicketId");

            migrationBuilder.CreateIndex(
                name: "IX_Ticket_TicketOwnerUserId",
                schema: "usr",
                table: "Ticket",
                column: "TicketOwnerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Ticket_TicketReportedUserId",
                schema: "usr",
                table: "Ticket",
                column: "TicketReportedUserId");

            migrationBuilder.CreateIndex(
                name: "IX_PeriodicTicket_TicketPriorityId",
                schema: "usr",
                table: "PeriodicTicket",
                column: "TicketPriorityId");

            migrationBuilder.AddForeignKey(
                name: "FK_PeriodicTicket_TicketPriority_TicketPriorityId",
                schema: "usr",
                table: "PeriodicTicket",
                column: "TicketPriorityId",
                principalSchema: "lst",
                principalTable: "TicketPriority",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_OwnerUserId_User_Id",
                schema: "usr",
                table: "Ticket",
                column: "TicketOwnerUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_PeriodicTicketId_PeriodicTicket_Id",
                schema: "usr",
                table: "Ticket",
                column: "PeriodicTicketId",
                principalSchema: "usr",
                principalTable: "PeriodicTicket",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_ReportedUserId_User_Id",
                schema: "usr",
                table: "Ticket",
                column: "TicketReportedUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);           
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PeriodicTicket_TicketPriority_TicketPriorityId",
                schema: "usr",
                table: "PeriodicTicket");

            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_OwnerUserId_User_Id",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_PeriodicTicketId_PeriodicTicket_Id",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_ReportedUserId_User_Id",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropForeignKey(
                name: "FK_User_Ticket_TicketId",
                schema: "idn",
                table: "User");

            migrationBuilder.DropIndex(
                name: "IX_User_TicketId",
                schema: "idn",
                table: "User");

            migrationBuilder.DropIndex(
                name: "IX_Ticket_PeriodicTicketId",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropIndex(
                name: "IX_Ticket_TicketOwnerUserId",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropIndex(
                name: "IX_Ticket_TicketReportedUserId",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropIndex(
                name: "IX_PeriodicTicket_TicketPriorityId",
                schema: "usr",
                table: "PeriodicTicket");

            migrationBuilder.DropColumn(
                name: "TicketId",
                schema: "idn",
                table: "User");
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class AddTicketStateRoleUserTableUpdateFKGlobals : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ticketstatelevel_ticketstate",
                schema: "lst",
                table: "TicketStateTransition");

            migrationBuilder.DropForeignKey(
                name: "FK_ticketstatelevel_ticketstate1",
                schema: "lst",
                table: "TicketStateTransition");

            migrationBuilder.CreateTable(
                name: "TicketStateRoleUser",
                schema: "idn",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false, comment: "TicketStateRoleUser tanım tablosunun primary keyi")
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TicketStateRoleId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    AddedByUserId = table.Column<int>(type: "int", nullable: true, defaultValueSql: "((1))"),
                    AddedTime = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "getdate()"),
                    LastModifiedByUserId = table.Column<int>(type: "int", nullable: true),
                    LastModifiedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))"),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((0))")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TicketStateRoleUser", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TicketStateRoleUser_AddedByUserId_User_Id",
                        column: x => x.AddedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TicketStateRoleUser_LastModifiedByUserId_User_Id",
                        column: x => x.LastModifiedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TicketStateRoleUser_TicketStateRoleId_TicketStateRole_Id",
                        column: x => x.TicketStateRoleId,
                        principalSchema: "lst",
                        principalTable: "TicketStateRole",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TicketStateRoleUser_UserId_User_Id",
                        column: x => x.UserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateRoleUser_AddedByUserId",
                schema: "idn",
                table: "TicketStateRoleUser",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateRoleUser_LastModifiedByUserId",
                schema: "idn",
                table: "TicketStateRoleUser",
                column: "LastModifiedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateRoleUser_TicketStateRoleId",
                schema: "idn",
                table: "TicketStateRoleUser",
                column: "TicketStateRoleId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateRoleUser_UserId",
                schema: "idn",
                table: "TicketStateRoleUser",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_TicketStateTransition_DestinationTicketStateId_ticketstate_Id",
                schema: "lst",
                table: "TicketStateTransition",
                column: "DestinationTicketStateId",
                principalSchema: "lst",
                principalTable: "TicketState",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TicketStateTransition_SourceTicketStateId_ticketstate_Id",
                schema: "lst",
                table: "TicketStateTransition",
                column: "SourceTicketStateId",
                principalSchema: "lst",
                principalTable: "TicketState",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TicketStateTransition_DestinationTicketStateId_ticketstate_Id",
                schema: "lst",
                table: "TicketStateTransition");

            migrationBuilder.DropForeignKey(
                name: "FK_TicketStateTransition_SourceTicketStateId_ticketstate_Id",
                schema: "lst",
                table: "TicketStateTransition");

            migrationBuilder.DropTable(
                name: "TicketStateRoleUser",
                schema: "idn");

            migrationBuilder.AddForeignKey(
                name: "FK_ticketstatelevel_ticketstate",
                schema: "lst",
                table: "TicketStateTransition",
                column: "DestinationTicketStateId",
                principalSchema: "lst",
                principalTable: "TicketState",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ticketstatelevel_ticketstate1",
                schema: "lst",
                table: "TicketStateTransition",
                column: "SourceTicketStateId",
                principalSchema: "lst",
                principalTable: "TicketState",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

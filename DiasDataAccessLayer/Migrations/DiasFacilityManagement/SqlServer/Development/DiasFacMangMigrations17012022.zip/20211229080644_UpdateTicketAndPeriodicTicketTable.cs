﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateTicketAndPeriodicTicketTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "TicketPriority",
                schema: "usr",
                table: "Ticket",
                newName: "TicketPriorityId");

            migrationBuilder.RenameColumn(
                name: "TicketPriority",
                schema: "usr",
                table: "PeriodicTicket",
                newName: "TicketPriorityId");

            migrationBuilder.CreateIndex(
                name: "IX_Ticket_TicketPriorityId",
                schema: "usr",
                table: "Ticket",
                column: "TicketPriorityId");

            migrationBuilder.AddForeignKey(
                name: "FK_ticket_ticketpriority",
                schema: "usr",
                table: "Ticket",
                column: "TicketPriorityId",
                principalSchema: "lst",
                principalTable: "TicketPriority",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ticket_ticketpriority",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropIndex(
                name: "IX_Ticket_TicketPriorityId",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.RenameColumn(
                name: "TicketPriorityId",
                schema: "usr",
                table: "Ticket",
                newName: "TicketPriority");

            migrationBuilder.RenameColumn(
                name: "TicketPriorityId",
                schema: "usr",
                table: "PeriodicTicket",
                newName: "TicketPriority");
        }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateMenuPageTablePKv13 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MenuPage",
                schema: "lst");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MenuPage",
                schema: "lst",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    AddedByUserId = table.Column<int>(type: "int", nullable: true, defaultValueSql: "((1))"),
                    AddedTime = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    ExpandOnStart = table.Column<bool>(type: "bit", nullable: false),
                    HierarchicalLevel = table.Column<int>(type: "int", nullable: false),
                    HierarchicalOrder = table.Column<int>(type: "int", nullable: false),
                    IdYedek = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))"),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((0))"),
                    LastModifiedByUserId = table.Column<int>(type: "int", nullable: true),
                    LastModifiedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    MenuIcon = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    MenuImagePath = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    MenuText = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    ParentId = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    UrlPath = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MenuPage", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MenuPage_AddedByUserId_User_Id",
                        column: x => x.AddedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MenuPage_LastModifiedByUserId_User_Id",
                        column: x => x.LastModifiedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MenuPage_AddedByUserId",
                schema: "lst",
                table: "MenuPage",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_MenuPage_LastModifiedByUserId",
                schema: "lst",
                table: "MenuPage",
                column: "LastModifiedByUserId");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class AddBasicTicketStateFkToBasicTicket : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BasicTicket_BasicTicketState_StateOfBasicStateId",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropIndex(
                name: "IX_BasicTicket_StateOfBasicStateId",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropColumn(
                name: "StateId",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropColumn(
                name: "StateOfBasicStateId",
                schema: "usr",
                table: "BasicTicket");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class AddFkToCompanyRoleClaim : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApiControllerDescriptionId",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_CompanyRoleClaim_ApiControllerDescriptionId",
                schema: "idn",
                table: "CompanyRoleClaim",
                column: "ApiControllerDescriptionId");

            migrationBuilder.AddForeignKey(
                name: "FK_CompanyRoleClaim_ApiControllerDescriptionId_ApiControllerDescription_Id",
                schema: "idn",
                table: "CompanyRoleClaim",
                column: "ApiControllerDescriptionId",
                principalSchema: "idn",
                principalTable: "ApiControllerDescription",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CompanyRoleClaim_ApiControllerDescriptionId_ApiControllerDescription_Id",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropIndex(
                name: "IX_CompanyRoleClaim_ApiControllerDescriptionId",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropColumn(
                name: "ApiControllerDescriptionId",
                schema: "idn",
                table: "CompanyRoleClaim");
        }
    }
}

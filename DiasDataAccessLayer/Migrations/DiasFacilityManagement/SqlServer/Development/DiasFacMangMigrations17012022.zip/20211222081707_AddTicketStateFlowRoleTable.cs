﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class AddTicketStateFlowRoleTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TicketStateFlowRole",
                schema: "idn",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TicketStateRoleId = table.Column<int>(type: "int", nullable: false),
                    TicketStateFlowId = table.Column<int>(type: "int", nullable: false),
                    PermissionGranted = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "((0))"),
                    AddedByUserId = table.Column<int>(type: "int", nullable: true, defaultValueSql: "((1))"),
                    AddedTime = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    LastModifiedByUserId = table.Column<int>(type: "int", nullable: true),
                    LastModifiedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))"),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((0))")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TicketStateFlowRole", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TicketStateFlowRole_AddedByUserId_User_Id",
                        column: x => x.AddedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TicketStateFlowRole_LastModifiedByUserId_User_Id",
                        column: x => x.LastModifiedByUserId,
                        principalSchema: "idn",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TicketStateFlowRole_TicketStateFlowId_TicketStateFlow_TicketStateFlowId",
                        column: x => x.TicketStateFlowId,
                        principalSchema: "lst",
                        principalTable: "TicketStateFlow",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_TicketStateFlowRole_TicketStateRoleId_TicketStateRole_TicketStateRoleId",
                        column: x => x.TicketStateRoleId,
                        principalSchema: "lst",
                        principalTable: "TicketStateRole",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateFlowRole_AddedByUserId",
                schema: "idn",
                table: "TicketStateFlowRole",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateFlowRole_LastModifiedByUserId",
                schema: "idn",
                table: "TicketStateFlowRole",
                column: "LastModifiedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateFlowRole_TicketStateFlowId",
                schema: "idn",
                table: "TicketStateFlowRole",
                column: "TicketStateFlowId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketStateFlowRole_TicketStateRoleId",
                schema: "idn",
                table: "TicketStateFlowRole",
                column: "TicketStateRoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TicketStateFlowRole",
                schema: "idn");
        }
    }
}

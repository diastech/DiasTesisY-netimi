﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class Update_LastModifiedTime_Attachment_TicketIdv2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "WorkShift");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "UserMenuPage");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "sym",
                table: "User");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "TicketStateTransition");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "TicketState");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "TicketRelatedLocation");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "TicketReasonCategoryV2");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "TicketReasonCategory");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "TicketReason");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "TicketPriority");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "TicketNote");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "TicketAuditHistory");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormYesNo");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormV2");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormSingleQuestion");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "ResolutionFormQuestionType");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormQuestionAnswer");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormQuestion");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormMultipleChoice");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormChoiceOption");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormAnswer");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionForm");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "PeriodicTicket");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "MenuPageV2");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "MenuPage");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "LocationV2");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "lst",
                table: "Location");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "usr",
                table: "Attachment");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "AssignmentGroupEmployee");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "AssignmentGroupAuthorizedLocation");

            migrationBuilder.DropColumn(
                name: "LastModifiedTime",
                schema: "adm",
                table: "AssignmentGroup");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "WorkShift",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "UserMenuPage",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "sym",
                table: "User",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "TicketStateTransition",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "TicketState",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "TicketRelatedLocation",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "TicketReasonCategoryV2",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "TicketReasonCategory",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "TicketReason",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "TicketPriority",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "TicketNote",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "TicketAuditHistory",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "Ticket",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormYesNo",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormV2",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormSingleQuestion",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "ResolutionFormQuestionType",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormQuestionAnswer",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormQuestion",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormMultipleChoice",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormChoiceOption",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionFormAnswer",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "ResolutionForm",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "PeriodicTicket",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "MenuPageV2",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "MenuPage",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "LocationV2",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "lst",
                table: "Location",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "BasicTicket",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "TicketId",
                schema: "usr",
                table: "Attachment",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "usr",
                table: "Attachment",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "AssignmentGroupEmployee",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "AssignmentGroupAuthorizedLocation",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedTime",
                schema: "adm",
                table: "AssignmentGroup",
                type: "datetime2",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "BeskWindeskLocation",
                schema: "lst",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AddedByUserId = table.Column<int>(type: "int", nullable: false, defaultValueSql: "((1))"),
                    AddedTime = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    Address = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: false),
                    AutoComplete = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    Category = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    City = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Code = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false),
                    CompanyCode = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    ConntactCode = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Country = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    County = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    DepartmentCode = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Description = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Email = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Fax = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    GroupNo = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    HourBegin = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Hourend = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Idate = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))"),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    Iuser = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    LastModifiedByUserId = table.Column<int>(type: "int", nullable: true),
                    LastModifiedTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Name = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: true),
                    ParentCode = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    Phone = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    RegionCode = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    Status = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    Udate = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    Uuser = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    XcmpCode = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    Zip = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BeskWindeskLocation", x => x.Id);
                });
        }
    }
}

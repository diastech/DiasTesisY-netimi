﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class TicketPriorityFKAdd : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_TicketPriority_AddedByUserId",
                schema: "lst",
                table: "TicketPriority",
                column: "AddedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_TicketPriority_LastModifiedByUserId",
                schema: "lst",
                table: "TicketPriority",
                column: "LastModifiedByUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_TicketPriority_AddedByUserId_User_Id",
                schema: "lst",
                table: "TicketPriority",
                column: "AddedByUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TicketPriority_LastModifiedByUserId_User_Id",
                schema: "lst",
                table: "TicketPriority",
                column: "LastModifiedByUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TicketPriority_AddedByUserId_User_Id",
                schema: "lst",
                table: "TicketPriority");

            migrationBuilder.DropForeignKey(
                name: "FK_TicketPriority_LastModifiedByUserId_User_Id",
                schema: "lst",
                table: "TicketPriority");

            migrationBuilder.DropIndex(
                name: "IX_TicketPriority_AddedByUserId",
                schema: "lst",
                table: "TicketPriority");

            migrationBuilder.DropIndex(
                name: "IX_TicketPriority_LastModifiedByUserId",
                schema: "lst",
                table: "TicketPriority");
        }
    }
}

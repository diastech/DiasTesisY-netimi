﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class testv2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_User_Ticket_TicketId",
            //    schema: "idn",
            //    table: "User");

            //migrationBuilder.DropIndex(
            //   name: "IX_User_TicketId",
            //   schema: "idn",
            //   table: "User");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TicketId",
                schema: "idn",
                table: "User",
                type: "int",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_User_Ticket_TicketId",
                schema: "idn",
                table: "User",
                column: "TicketId",
                principalSchema: "usr",
                principalTable: "Ticket",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateCompanyRoleClaimTableMenuPageTablev5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "IdYedek",
                schema: "lst",
                table: "MenuPage",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "ApiControllerDescriptionId",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "MenuPageId",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MenuPageV2Id",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RestClientTypeId",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_CompanyRoleClaim_MenuPageV2Id",
                schema: "idn",
                table: "CompanyRoleClaim",
                column: "MenuPageV2Id");

            migrationBuilder.AddForeignKey(
                name: "FK_CompanyRoleClaim_MenuPageV2Id_MenuPageV2_Id",
                schema: "idn",
                table: "CompanyRoleClaim",
                column: "MenuPageV2Id",
                principalSchema: "lst",
                principalTable: "MenuPageV2",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CompanyRoleClaim_MenuPageV2Id_MenuPageV2_Id",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropIndex(
                name: "IX_CompanyRoleClaim_MenuPageV2Id",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropColumn(
                name: "IdYedek",
                schema: "lst",
                table: "MenuPage");

            migrationBuilder.DropColumn(
                name: "MenuPageId",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropColumn(
                name: "MenuPageV2Id",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropColumn(
                name: "RestClientTypeId",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.AlterColumn<int>(
                name: "ApiControllerDescriptionId",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateMenuPageTablePKv15 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "MenuPageYedek",
                schema: "lst",
                newName: "MenuPage",
                newSchema: "lst");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "MenuPage",
                schema: "lst",
                newName: "MenuPageYedek",
                newSchema: "lst");
        }
    }
}

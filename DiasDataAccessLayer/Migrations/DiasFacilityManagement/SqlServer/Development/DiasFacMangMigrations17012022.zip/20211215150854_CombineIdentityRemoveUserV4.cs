﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class CombineIdentityRemoveUserV4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_CompanyRole_ParentCompanyRoleId",
                schema: "idn",
                table: "CompanyRole",
                column: "ParentCompanyRoleId");

            migrationBuilder.AddForeignKey(
                name: "FK_CompanyRole_AddedByParentCompanyRoleId_CompanyRole_ParentCompanyRoleId",
                schema: "idn",
                table: "CompanyRole",
                column: "ParentCompanyRoleId",
                principalSchema: "idn",
                principalTable: "CompanyRole",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CompanyRole_AddedByParentCompanyRoleId_CompanyRole_ParentCompanyRoleId",
                schema: "idn",
                table: "CompanyRole");

            migrationBuilder.DropIndex(
                name: "IX_CompanyRole_ParentCompanyRoleId",
                schema: "idn",
                table: "CompanyRole");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateTTicketStateFlowRoleTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TicketStateFlowRole_TicketStateFlowId_TicketStateFlow_TicketStateFlowId",
                schema: "idn",
                table: "TicketStateFlowRole");

            migrationBuilder.RenameColumn(
                name: "TicketStateFlowId",
                schema: "idn",
                table: "TicketStateFlowRole",
                newName: "TicketStateTransitionFlowId");

            migrationBuilder.RenameIndex(
                name: "IX_TicketStateFlowRole_TicketStateFlowId",
                schema: "idn",
                table: "TicketStateFlowRole",
                newName: "IX_TicketStateFlowRole_TicketStateTransitionFlowId");

            migrationBuilder.AddForeignKey(
                name: "FK_TicketStateFlowRole_TicketStateTransitionFlowId_TicketStateTransitionFlow_Id",
                schema: "idn",
                table: "TicketStateFlowRole",
                column: "TicketStateTransitionFlowId",
                principalSchema: "lst",
                principalTable: "TicketStateTransitionFlow",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TicketStateFlowRole_TicketStateTransitionFlowId_TicketStateTransitionFlow_Id",
                schema: "idn",
                table: "TicketStateFlowRole");

            migrationBuilder.RenameColumn(
                name: "TicketStateTransitionFlowId",
                schema: "idn",
                table: "TicketStateFlowRole",
                newName: "TicketStateFlowId");

            migrationBuilder.RenameIndex(
                name: "IX_TicketStateFlowRole_TicketStateTransitionFlowId",
                schema: "idn",
                table: "TicketStateFlowRole",
                newName: "IX_TicketStateFlowRole_TicketStateFlowId");

            migrationBuilder.AddForeignKey(
                name: "FK_TicketStateFlowRole_TicketStateFlowId_TicketStateFlow_TicketStateFlowId",
                schema: "idn",
                table: "TicketStateFlowRole",
                column: "TicketStateFlowId",
                principalSchema: "lst",
                principalTable: "TicketStateFlow",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

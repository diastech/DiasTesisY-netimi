﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateIdentityTablesv2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
           
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_CompanyRoleClaim_AddedByUserId_User_Id",
            //    schema: "idn",
            //    table: "CompanyRoleClaim");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_CompanyRoleClaim_LastModifiedByUserId_User_Id",
            //    schema: "idn",
            //    table: "CompanyRoleClaim");

            //migrationBuilder.AddForeignKey(
            //    name: "FK_CompanyRole_AddedByUserId_User_Id",
            //    schema: "idn",
            //    table: "CompanyRole",
            //    column: "AddedByUserId",
            //    principalSchema: "idn",
            //    principalTable: "User",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Restrict);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_CompanyRole_LastModifiedByUserId_User_Id",
            //    schema: "idn",
            //    table: "CompanyRole",
            //    column: "LastModifiedByUserId",
            //    principalSchema: "idn",
            //    principalTable: "User",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Restrict);
        }
    }
}

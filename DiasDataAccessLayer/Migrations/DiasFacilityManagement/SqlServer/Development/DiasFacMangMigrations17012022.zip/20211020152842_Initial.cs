﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using NetTopologySuite.Geometries;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        { }


        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_WorkShift_AddedByUserId_User_Id",
                schema: "lst",
                table: "WorkShift");

            migrationBuilder.DropForeignKey(
                name: "FK_WorkShift_LastModifiedByUserId_User_Id",
                schema: "lst",
                table: "WorkShift");

            migrationBuilder.DropTable(
                name: "AssignmentGroupAuthorizedLocation",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "AssignmentGroupEmployee",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "Attachment",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "Location",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "MenuPage",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "MenuPageV2",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "PeriodicTicket",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "ResolutionFormAnswer",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionFormChoiceOption",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionFormMultipleChoice",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionFormQuestionAnswer",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionFormSingleQuestion",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionFormYesNo",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "TicketAuditHistory",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "TicketReasonCategory",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "TicketStateTransition",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "UserMenuPage",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "TicketNote",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "TicketRelatedLocation",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "ResolutionFormV2",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionFormQuestion",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "ResolutionForm",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "LocationV2",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "Ticket",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "ResolutionFormQuestionType",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "AssignmentGroup",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "BasicTicket",
                schema: "usr");

            migrationBuilder.DropTable(
                name: "TicketState",
                schema: "lst");

            migrationBuilder.DropTable(
                name: "TicketReason",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "TicketReasonCategoryV2",
                schema: "adm");

            migrationBuilder.DropTable(
                name: "User",
                schema: "sym");

            migrationBuilder.DropTable(
                name: "WorkShift",
                schema: "lst");
        }
    }
}

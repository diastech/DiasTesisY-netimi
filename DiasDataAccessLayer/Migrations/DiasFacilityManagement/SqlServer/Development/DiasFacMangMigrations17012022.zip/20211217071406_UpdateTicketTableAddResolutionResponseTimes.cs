﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateTicketTableAddResolutionResponseTimes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "ExpectedResolutionTime",
                schema: "usr",
                table: "Ticket",
                type: "datetime",
                nullable: false,
                defaultValueSql: "(getdate())");

            migrationBuilder.AddColumn<DateTime>(
                name: "ExpectedResponseTime",
                schema: "usr",
                table: "Ticket",
                type: "datetime",
                nullable: false,
                defaultValueSql: "(getdate())");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExpectedResolutionTime",
                schema: "usr",
                table: "Ticket");

            migrationBuilder.DropColumn(
                name: "ExpectedResponseTime",
                schema: "usr",
                table: "Ticket");
        }
    }
}

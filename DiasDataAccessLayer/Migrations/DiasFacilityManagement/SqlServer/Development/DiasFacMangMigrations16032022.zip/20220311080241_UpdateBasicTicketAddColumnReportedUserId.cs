﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateBasicTicketAddColumnReportedUserId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ReportedUserId",
                schema: "usr",
                table: "BasicTicket",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_BasicTicket_ReportedUserId",
                schema: "usr",
                table: "BasicTicket",
                column: "ReportedUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_BasicTicket_ReportedUserId_User_Id",
                schema: "usr",
                table: "BasicTicket",
                column: "ReportedUserId",
                principalSchema: "idn",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BasicTicket_ReportedUserId_User_Id",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropIndex(
                name: "IX_BasicTicket_ReportedUserId",
                schema: "usr",
                table: "BasicTicket");

            migrationBuilder.DropColumn(
                name: "ReportedUserId",
                schema: "usr",
                table: "BasicTicket");
        }
    }
}

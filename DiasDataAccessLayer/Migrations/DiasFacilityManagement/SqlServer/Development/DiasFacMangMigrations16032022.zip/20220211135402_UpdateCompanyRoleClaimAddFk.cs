﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DiasDataAccessLayer.Migrations.DiasFacilityManagement.SqlServer.Development
{
    public partial class UpdateCompanyRoleClaimAddFk : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TicketStateRoleId",
                schema: "idn",
                table: "CompanyRoleClaim",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_CompanyRoleClaim_TicketStateRoleId",
                schema: "idn",
                table: "CompanyRoleClaim",
                column: "TicketStateRoleId");

            migrationBuilder.AddForeignKey(
                name: "FK_CompanyRoleClaim_TicketStateRoleId_TicketStateRole_Id",
                schema: "idn",
                table: "CompanyRoleClaim",
                column: "TicketStateRoleId",
                principalSchema: "lst",
                principalTable: "TicketStateRole",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CompanyRoleClaim_TicketStateRoleId_TicketStateRole_Id",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropIndex(
                name: "IX_CompanyRoleClaim_TicketStateRoleId",
                schema: "idn",
                table: "CompanyRoleClaim");

            migrationBuilder.DropColumn(
                name: "TicketStateRoleId",
                schema: "idn",
                table: "CompanyRoleClaim");
        }
    }
}
